import { useState, useEffect, useMemo } from "react";
import { Sun, Moon, Flame, Droplet, Wheat, Plus, TrendingDown, X } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

const FONT_LINK_ID = "shift-planner-fonts";

const THEMES = {
  day: {
    bg: "#FBF5EC",
    bgSecondary: "#F1E6D3",
    card: "#FFFFFF",
    text: "#2B2520",
    textMuted: "#8A7C68",
    accent: "#B8722A",
    accentSoft: "#EAD3AE",
    protein: "#5B7A5B",
    proteinSoft: "#DCE6D9",
    border: "#E7DAC4",
  },
  night: {
    bg: "#0E1120",
    bgSecondary: "#171C30",
    card: "#1C2239",
    text: "#E7E4DC",
    textMuted: "#8B90A6",
    accent: "#8B94D6",
    accentSoft: "#2C3155",
    protein: "#8FAE8A",
    proteinSoft: "#26302A",
    border: "#2A3050",
  },
};

const TARGETS = {
  kcalLow: 2400,
  kcalHigh: 2500,
  protein: 180,
  fat: 75,
  carbs: 250,
};

const MEALS = {
  day: [
    {
      slot: "Frühstück",
      time: "vor Dienstbeginn",
      options: [
        { name: "Skyr mit Haferflocken & Beeren", kcal: 480, protein: 38, note: "500g Skyr, 60g Haferflocken, Beeren, 1 EL Honig" },
        { name: "Rührei mit Vollkornbrot & Avocado", kcal: 510, protein: 32, note: "3 Eier, 2 Scheiben Vollkorn, halbe Avocado" },
        { name: "Proteinshake & Vollkorntoast mit Erdnussbutter", kcal: 460, protein: 40, note: "1 Scoop Whey, 2 Toast, 1 EL Erdnussbutter" },
      ],
    },
    {
      slot: "Mittagessen",
      time: "in der Pause",
      options: [
        { name: "Hähnchenbrust mit Reis & Gemüse", kcal: 650, protein: 50, note: "150g Hähnchen, 200g Reis, gedünstetes Gemüse" },
        { name: "Linsen-Curry mit Naturjoghurt", kcal: 600, protein: 30, note: "Rote Linsen, Kokosmilch light, Naturjoghurt dazu" },
        { name: "Pute-Wrap mit Vollkornfladen", kcal: 580, protein: 42, note: "Putenbrust, Vollkornfladen, Salat, Hummus" },
      ],
    },
    {
      slot: "Snack",
      time: "Nachmittag",
      options: [
        { name: "Magerquark mit Obst", kcal: 220, protein: 24, note: "250g Magerquark, 1 Stück Obst" },
        { name: "Handvoll Nüsse & Apfel", kcal: 260, protein: 8, note: "30g gemischte Nüsse" },
        { name: "Proteinriegel", kcal: 210, protein: 20, note: "z.B. 1 Riegel ~20g Protein" },
      ],
    },
    {
      slot: "Abendessen",
      time: "nach Dienstende",
      options: [
        { name: "Lachs mit Ofengemüse", kcal: 620, protein: 40, note: "150g Lachs, buntes Ofengemüse, wenig Öl" },
        { name: "Rinderhack-Pfanne mit Zucchini & Kartoffeln", kcal: 600, protein: 45, note: "150g Hack mager, Zucchini, 250g Kartoffeln" },
        { name: "Gemüse-Omelett mit Feta", kcal: 520, protein: 34, note: "4 Eier, Gemüse, 40g Feta" },
      ],
    },
  ],
  night: [
    {
      slot: "Vor Dienstbeginn",
      time: "ca. 18:00",
      options: [
        { name: "Hähnchen mit Süßkartoffel & Brokkoli", kcal: 650, protein: 48, note: "150g Hähnchen, 250g Süßkartoffel, Brokkoli" },
        { name: "Vollkornpasta mit Hackfleischsauce", kcal: 630, protein: 44, note: "80g Vollkornpasta trocken, 150g Hack mager" },
        { name: "Gebratener Reis mit Ei & Gemüse", kcal: 580, protein: 30, note: "200g Reis, 2 Eier, Gemüse, wenig Sojasauce" },
      ],
    },
    {
      slot: "Mitte der Nacht",
      time: "ca. 00:00–02:00",
      options: [
        { name: "Magerquark mit Nüssen", kcal: 280, protein: 30, note: "250g Magerquark, 20g Nüsse — sättigt, macht nicht müde" },
        { name: "Proteinshake", kcal: 180, protein: 30, note: "1–1,5 Scoop Whey in Wasser oder Milch" },
        { name: "Truthahnbrust-Wrap klein", kcal: 320, protein: 28, note: "Kleiner Vollkornwrap, Putenbrust, Salat" },
      ],
    },
    {
      slot: "Nach Dienstende",
      time: "ca. 7:30, vor dem Schlafen",
      options: [
        { name: "Kleines Rührei (leicht)", kcal: 280, protein: 22, note: "2 Eier, wenig Fett — bewusst klein halten" },
        { name: "Skyr mit wenig Obst", kcal: 250, protein: 22, note: "300g Skyr, kleine Portion Beeren" },
        { name: "Proteinshake klein", kcal: 160, protein: 25, note: "1 Scoop Whey, Wasser" },
      ],
    },
  ],
};

const STORAGE_KEY = "weight-entries";

export default function App() {
  const [shift, setShift] = useState("day");
  const [selected, setSelected] = useState({});
  const [entries, setEntries] = useState([]);
  const [newWeight, setNewWeight] = useState("");
  const [loading, setLoading] = useState(true);
  const [saveError, setSaveError] = useState(false);

  const t = THEMES[shift];

  useEffect(() => {
    if (!document.getElementById(FONT_LINK_ID)) {
      const link = document.createElement("link");
      link.id = FONT_LINK_ID;
      link.rel = "stylesheet";
      link.href =
        "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=Inter:wght@400;500;600&family=IBM+Plex+Mono:wght@500&display=swap";
      document.head.appendChild(link);
    }
  }, []);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setEntries(JSON.parse(raw));
    } catch (e) {
      // no entries yet
    } finally {
      setLoading(false);
    }
  }, []);

  const addWeight = () => {
    const val = parseFloat(newWeight.replace(",", "."));
    if (!val || val <= 0) return;
    const entry = { date: new Date().toISOString().slice(0, 10), weight: val };
    const updated = [...entries.filter((e) => e.date !== entry.date), entry].sort((a, b) =>
      a.date.localeCompare(b.date)
    );
    setEntries(updated);
    setNewWeight("");
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      setSaveError(false);
    } catch (e) {
      setSaveError(true);
    }
  };

  const chartData = useMemo(
    () => entries.map((e) => ({ ...e, label: e.date.slice(5) })),
    [entries]
  );

  const toggle = (slot, idx) =>
    setSelected((prev) => ({ ...prev, [slot]: prev[slot] === idx ? undefined : idx }));

  return (
    <div
      style={{
        minHeight: "100vh",
        background: t.bg,
        color: t.text,
        fontFamily: "'Inter', sans-serif",
        transition: "background 0.4s ease, color 0.4s ease",
        paddingBottom: 48,
      }}
    >
      {/* Hero */}
      <div style={{ padding: "32px 20px 24px", maxWidth: 640, margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
          <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 12, letterSpacing: 1.5, color: t.textMuted, textTransform: "uppercase" }}>
            Schicht-Ernährungsplan
          </span>
          <div
            onClick={() => setShift(shift === "day" ? "night" : "day")}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => e.key === "Enter" && setShift(shift === "day" ? "night" : "day")}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 8,
              background: t.bgSecondary,
              border: `1px solid ${t.border}`,
              borderRadius: 999,
              padding: "6px 14px",
              cursor: "pointer",
              fontSize: 13,
              fontWeight: 500,
            }}
          >
            {shift === "day" ? <Sun size={16} color={t.accent} /> : <Moon size={16} color={t.accent} />}
            {shift === "day" ? "Tagdienst" : "Nachtdienst"}
          </div>
        </div>

        <h1
          style={{
            fontFamily: "'Fraunces', serif",
            fontWeight: 600,
            fontSize: 20,
            lineHeight: 1.3,
            margin: "0 0 20px",
            color: t.textMuted,
          }}
        >
          {shift === "day" ? "Ausgewogen durch den Tagdienst" : "Konstant durch die Nacht"}
        </h1>

        <div
          style={{
            background: t.card,
            border: `1px solid ${t.border}`,
            borderRadius: 20,
            padding: "24px 24px 20px",
          }}
        >
          <div style={{ display: "flex", alignItems: "baseline", gap: 10 }}>
            <span style={{ fontFamily: "'Fraunces', serif", fontSize: 52, fontWeight: 600, color: t.accent, lineHeight: 1 }}>
              {TARGETS.kcalLow}–{TARGETS.kcalHigh}
            </span>
            <span style={{ fontSize: 14, color: t.textMuted }}>kcal / Tag</span>
          </div>
          <div style={{ display: "flex", gap: 16, marginTop: 18, flexWrap: "wrap" }}>
            <Macro icon={<Droplet size={14} color={t.protein} />} label="Protein" value={`${TARGETS.protein} g`} t={t} />
            <Macro icon={<Flame size={14} color={t.accent} />} label="Fett" value={`${TARGETS.fat} g`} t={t} />
            <Macro icon={<Wheat size={14} color={t.textMuted} />} label="Kohlenhydrate" value={`${TARGETS.carbs} g`} t={t} />
          </div>
        </div>
      </div>

      {/* Meals */}
      <div style={{ maxWidth: 640, margin: "0 auto", padding: "0 20px" }}>
        {MEALS[shift].map((meal) => (
          <div key={meal.slot} style={{ marginBottom: 28 }}>
            <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginBottom: 10 }}>
              <h2 style={{ fontFamily: "'Fraunces', serif", fontSize: 17, fontWeight: 600, margin: 0 }}>
                {meal.slot}
              </h2>
              <span style={{ fontSize: 12, color: t.textMuted }}>{meal.time}</span>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {meal.options.map((opt, idx) => {
                const isSelected = selected[meal.slot] === idx;
                return (
                  <div
                    key={opt.name}
                    onClick={() => toggle(meal.slot, idx)}
                    role="button"
                    tabIndex={0}
                    onKeyDown={(e) => e.key === "Enter" && toggle(meal.slot, idx)}
                    style={{
                      background: isSelected ? t.accentSoft : t.card,
                      border: `1px solid ${isSelected ? t.accent : t.border}`,
                      borderRadius: 14,
                      padding: "14px 16px",
                      cursor: "pointer",
                      transition: "background 0.2s ease, border-color 0.2s ease",
                    }}
                  >
                    <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
                      <span style={{ fontWeight: 500, fontSize: 14.5 }}>{opt.name}</span>
                      <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 12.5, color: t.textMuted, whiteSpace: "nowrap" }}>
                        {opt.kcal} kcal
                      </span>
                    </div>
                    <div style={{ display: "flex", justifyContent: "space-between", marginTop: 4, gap: 12 }}>
                      <span style={{ fontSize: 12.5, color: t.textMuted }}>{opt.note}</span>
                      <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 12, color: t.protein, whiteSpace: "nowrap" }}>
                        {opt.protein}g P
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Weight tracker */}
      <div style={{ maxWidth: 640, margin: "0 auto", padding: "8px 20px 0" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
          <TrendingDown size={17} color={t.accent} />
          <h2 style={{ fontFamily: "'Fraunces', serif", fontSize: 17, fontWeight: 600, margin: 0 }}>Gewichtsverlauf</h2>
        </div>

        <div style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 16, padding: 16 }}>
          <div style={{ display: "flex", gap: 8, marginBottom: entries.length ? 16 : 0 }}>
            <input
              value={newWeight}
              onChange={(e) => setNewWeight(e.target.value)}
              placeholder="z.B. 100,4"
              inputMode="decimal"
              style={{
                flex: 1,
                background: t.bgSecondary,
                border: `1px solid ${t.border}`,
                borderRadius: 10,
                padding: "10px 12px",
                color: t.text,
                fontSize: 14,
                fontFamily: "'IBM Plex Mono', monospace",
              }}
            />
            <button
              onClick={addWeight}
              style={{
                background: t.accent,
                border: "none",
                borderRadius: 10,
                padding: "0 16px",
                color: t.bg,
                fontWeight: 600,
                fontSize: 14,
                display: "flex",
                alignItems: "center",
                gap: 6,
                cursor: "pointer",
              }}
            >
              <Plus size={16} /> kg
            </button>
          </div>

          {saveError && (
            <p style={{ fontSize: 12, color: "#C0554A", marginTop: 8 }}>
              Speichern hat gerade nicht geklappt — Eintrag bleibt nur für diese Sitzung sichtbar.
            </p>
          )}

          {!loading && chartData.length > 1 && (
            <div style={{ width: "100%", height: 180 }}>
              <ResponsiveContainer>
                <LineChart data={chartData} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
                  <CartesianGrid stroke={t.border} strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="label" tick={{ fontSize: 11, fill: t.textMuted }} axisLine={{ stroke: t.border }} tickLine={false} />
                  <YAxis
                    domain={["dataMin - 1", "dataMax + 1"]}
                    tick={{ fontSize: 11, fill: t.textMuted }}
                    axisLine={false}
                    tickLine={false}
                    width={38}
                  />
                  <Tooltip
                    contentStyle={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 8, fontSize: 12 }}
                    labelStyle={{ color: t.textMuted }}
                  />
                  <Line type="monotone" dataKey="weight" stroke={t.accent} strokeWidth={2.5} dot={{ r: 3, fill: t.accent }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}

          {!loading && entries.length === 0 && (
            <p style={{ fontSize: 13, color: t.textMuted, margin: 0 }}>
              Noch keine Einträge — trag dein Gewicht ein, um den Verlauf zu sehen.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

function Macro({ icon, label, value, t }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
      {icon}
      <span style={{ fontSize: 12.5, color: t.textMuted }}>{label}</span>
      <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 12.5, fontWeight: 500 }}>{value}</span>
    </div>
  );
}
