# Schicht-Ernährungsplan

Eine kleine React-App für Ernährung im Schichtdienst (Tag/Nacht) im Spital: Kalorien- und Makroziele, mehrere Mahlzeit-Optionen pro Slot, und ein Gewichtsverlauf-Tracker (gespeichert im Browser über `localStorage`).

## Lokal starten

```bash
npm install
npm run dev
```

Dann im Browser die angezeigte lokale Adresse öffnen (meist `http://localhost:5173`).

## Build für Produktion

```bash
npm run build
```

Das erzeugt einen `dist/`-Ordner mit der fertigen, statischen App.

## Auf GitHub hochladen

```bash
git init
git add .
git commit -m "Initial commit: Schicht-Ernährungsplan"
git branch -M main
git remote add origin https://github.com/<dein-username>/<dein-repo>.git
git push -u origin main
```

(Vorher auf GitHub ein leeres Repository anlegen und die URL oben eintragen.)

## Kostenlos live schalten (optional)

Am einfachsten mit **GitHub Pages**, **Vercel** oder **Netlify** — alle drei erkennen ein Vite-Projekt automatisch:

- **Vercel/Netlify**: Repo importieren, Build-Command `npm run build`, Output-Ordner `dist` — fertig.
- **GitHub Pages**: `vite.config.js` um `base: "/<dein-repo-name>/"` ergänzen, dann `npm run build` und den Inhalt von `dist/` auf den `gh-pages`-Branch pushen (z. B. mit dem Paket `gh-pages`).

## Anpassen

- Kalorienziele und Makros: `TARGETS` in `src/App.jsx`
- Mahlzeit-Optionen: `MEALS` in `src/App.jsx`
- Farben/Design: `THEMES` in `src/App.jsx`

## Hinweis zum Gewichtsverlauf

Die Daten liegen in `localStorage` deines Browsers — sie sind also gerätegebunden und gehen beim Löschen der Browserdaten verloren. Für einen geräteübergreifenden Verlauf bräuchte es später ein echtes Backend (z. B. Supabase, Firebase).
